import java.util.Scanner;

public class soal_no5 {


    public static void main(String args[]) {
       String input;
       char huruf;
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Masukkan Kata : ");
		input = sc.nextLine();
        
        System.out.print("Masukkan Huruf : ");
		huruf = sc.findInLine(".").charAt(0);;
        
      
        int charCount = 0;
        for(char ch: input.toCharArray()){
            if(ch == huruf){
                charCount++;
            }
        }     
        System.out.println("Jumlah huruf "+" '"+ huruf +"' "+" pada Kata "+" '"+ input +"' "+" adalah sebanyak: "+ charCount);
    }
      
    }
  
        


